After merge r308 from trunk:
http://www.netperf.org/pipermail/netperf-talk/2009-July/000602.html

NetPerf 2.4.5 can run on my Windows XP SP3 smoothly.
